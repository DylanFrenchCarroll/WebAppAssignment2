import _ from "lodash";
import superagent from "superagent";

// import { Component } from 'react';

class StubAPI {
  async getAll() {
    try {
      const res = await superagent.get(`${process.env.REACT_APP_SERVERURL}/posts`);
      console.log(res);
      let posts = JSON.parse(res.text);
      return await posts;
    } catch (err) {
      console.error(err);
    }
  }


  async login(username, password) {
    try {
      const res = await superagent
        .post(`${process.env.REACT_APP_SERVERURL}/users/login`)
        .set({
          "Content-type": "application/json"
        })
        .send(
          JSON.stringify({
            username: username,
            password: password
          })
        );
      console.log(res);
      localStorage.setItem( "token", res.body.token);
    } catch (err) {
      console.error(err);
    }
  }

  async signUp(username, password) {
    try {
      const res = await superagent
        .post(`${process.env.REACT_APP_SERVERURL}/users/add`)
        .set({
          "Content-type": "application/json"
        })
        .send(
          JSON.stringify({
            username: username,
            password: password
          })
        );
      console.log(res);
    } catch (err) {
      console.error(err);
    }
  }

  async add(title, artist, link) {
    try {
      const res = await superagent
        .post(`${process.env.REACT_APP_SERVERURL}/posts/add`)
        .set({
          "Content-type": "application/json", 
          Authorization: localStorage.getItem("token") || ""
        })
        .send(
          JSON.stringify({
            title: title,
            artist: artist,
            link: link
          })
        );
      console.log(res);
    } catch (err) {
      console.error(err);
    }
  }

  async deletePost(postId) {
    const res = await superagent
      .delete(`${process.env.REACT_APP_SERVERURL}/posts/${postId}`)
      .send();
    console.log(res);
    window.location.reload();
  }

  async upvote(post) {
    const res = await superagent
      .put(`${process.env.REACT_APP_SERVERURL}/posts/upvote`)
      .set({
        "Content-type": "application/json"
      })
      .send(
        JSON.stringify({
          title: post.title,
          upvotes: post.upvotes
        })
      );
    console.log(res);
    window.location.reload();
  }

  getPost(id) {
    let index = _.findIndex(this.posts, post => post.id === id);
    let result = index !== -1 ? this.posts[index] : null;
    return result;
  }

  addComment(postId, c, n) {
    let post = this.getPost(postId);
    let id = 1;
    let last = _.last(post.comments);
    if (last) {
      id = last.id + 1;
    }
    post.comments.push({ id: id, comment: c, artist: n, upvotes: 0 });
  }

  upvoteComment(postId, commentId) {
    let post = this.getPost(postId);
    let index = _.findIndex(post.comments, c => c.id === commentId);
    if (index !== -1) {
      post.comments[index].upvotes += 1;
    }
  }
} ///end do not go past
export default new StubAPI();
