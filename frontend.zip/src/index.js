import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import "./index.css";
import App from "./App";
import CommentPage from "./components/commentPage";
import Login from "./components/login";
import Help from "./components/Help.js";

const Router = (props) => {
  return (
    <BrowserRouter>
    <body>
        
              <h1 align="center" > Dylan's Playlist </h1>
             
            <nav class="navbar navbar-expand-sm  ">
                    <ul class="navbar-nav">
                    <li class="nav-item active ">
                      <Link class="nav-link" to="/">Home</Link>
                    </li>
                    <li class="nav-item active">
                      <Link class="nav-link" to="/help">Help</Link>   </li>
                    <li class="nav-item active">
                      <Link class="nav-link" to="/login">Login</Link>  
                    </li>
                    </ul>
            </nav>        
        <Switch>
          <Route path="/posts/:post_id" component={CommentPage} />
          <Route exact path="/" component={App} />
          <Route path = "/help" component= {Help}  />
          <Route path = "/login" component= {Login}  />
          <Redirect from="*" to="/" />
        </Switch>
      
      </body>
    </BrowserRouter>
  );
};

ReactDOM.render(<Router />, document.getElementById("root"));

