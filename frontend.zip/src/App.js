import React, { Component } from 'react';
import PostList from './components/songList/';
import Form from './components/songForm/';
import api from './dataStore/stubAPI';
import _ from 'lodash';
import "./App.css"

export default class App extends Component {    

    constructor(props) {
       super(props);
       this.state= {  posts:[]   }
    }
   async componentDidMount(){
    this.setState({posts: await api.getAll()})
    }

    addSongItem = (title, artist, link) => {
        api.add(title, artist, link);
        this.setState({});
      };


    incrementUpvote = (id) => {
        api.upvote(id) ;
        this.setState({});
    };

    
     render() {
        console.log(this.state.posts);
        return (
            <body>
          <div className = "back">
                <Form handleAdd={this.addSongItem} />
             
                <PostList posts={this.state.posts} upvoteHandler={this.incrementUpvote} />
         </div>
         </body>
        );
    }
}