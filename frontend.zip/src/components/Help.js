import React, { Component } from "react";
import "./help.css";
// import api from '../dataStore/stubAPI';
// import _ from 'lodash';


export default class Help extends Component {
    constructor(props){
        super(props);
        this.help = "This is a web app based on hackerNews but changed some front end and created a back end with express, node and mongodb/Atlas.";
       
        this.state = {};
    }

render(){
    //sorting
    //   posts.sort(api.dynamicSort("name"));
    //   console.log(posts);
    return (
    <body className="font"> {this.help} </body>
   
     );
}

}




