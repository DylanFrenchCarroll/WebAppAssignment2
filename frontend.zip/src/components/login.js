import React, { Component } from "react";
import "./help.css";
import api from "../dataStore/stubAPI"



export default class Login extends Component {
  state = { userName: "", password: "" };
  handleUserNameChange = e => this.setState({ userName: e.target.value });
  handlePasswordChange = e => this.setState({ password: e.target.value });

  handleSubmitLogin = e => {
    e.preventDefault();
    api.login(this.state.userName, this.state.password)
    console.log("logged in");
  };

  handleSubmitSignup = e => {
    e.preventDefault();
    api.signUp(this.state.userName, this.state.password);
    console.log("User Added");
    
  };
  render() {
    return (
      <div>
        <form className="login">
          <h3>Login</h3>

          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              value={this.state.userName}
              onChange={this.handleUserNameChange}
            />
          </div>

          <div className="form-group">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={this.state.password}
              onChange={this.handlePasswordChange}
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            onClick={this.handleSubmitLogin}
          >
            Login
          </button>
        </form>

        <form className="login">
          <h3>Sign up</h3>

          <div className="form-group">
            <input
              type="text"
              className="form-control"
              placeholder="Username"
              value={this.state.userName}
              onChange={this.handleUserNameChange}
            />
          </div>

          <div className="form-group">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              value={this.state.password}
              onChange={this.handlePasswordChange}
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            onClick={this.handleSubmitSignup}
          >
           Join
          </button>
        </form>
      </div>
    );
  }
}
