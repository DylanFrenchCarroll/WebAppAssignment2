import React, { Component, Fragment } from 'react';
import SongItem from '../songItem/';

export default class SongList extends Component {
  render() {
   this.props.posts.sort((a,b) => {
      return b.upvotes - a.upvotes;

    } );
    console.log("Sorted");
   

    let items = this.props.posts.map(
     (post,index) => 
         <SongItem key={index} 
             post={post} 
             upvoteHandler={this.props.upvoteHandler} /> 
     );
     
      return <Fragment>{items}</Fragment>;
    }
  }