import React, { Component, Fragment } from "react";
import "./songItem.css";
import "../../fontawesome";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";
import api from "../../dataStore/stubAPI";

export default class SongItem extends Component {
  handleVote = () => api.upvote(this.props.post);
  handleDelete = () => api.deletePost(this.props.post._id)
  

  render() {
    console.log(this.props.post);
    let link = this.props.post.link ? (
      <a href={this.props.post.link}>{this.props.post.title}</a>
    ) : (
      <span>{this.props.post.title}</span>
    );
    return (
      <Fragment>
        <span className="ptr" onClick={this.handleVote}>
          <FontAwesomeIcon icon={["fas", "thumbs-up"]} size="2x" />
          {` ${this.props.post.upvotes}`}
        </span>
        <span className="songitem">
          {link}

          

          <span>
            <Link to={`/posts/${this.props.post.id}`}>Comments</Link>
            <button className="btn btn-primary"
                onClick={this.handleDelete}>Delete</button>

          </span>
        </span>
        <p className="artist">{this.props.post.artist}</p>

       
      </Fragment>
    );
  }
}
