import React, { Component } from 'react';
import './songForm.css';

export default class Form extends Component {

  state = { title: '', artist: '', link: ''};

  handleSubmit = (e) => {
    e.preventDefault(); //stop refreshing page
    this.props.handleAdd( this.state.title, this.state.artist, this.state.link)
    this.setState({ title: '', artist:'', link: ''})
    window.location.reload();
}
  handleTitleChange = (e) =>  this.setState({title: e.target.value});
  handleArtistChange = (e) =>  this.setState({artist: e.target.value});
  handleLinkChange = (e) => this.setState({link: e.target.value});

  render() {
    return (
        <body>
     <form className="pad"  >
         <h3>Add a song</h3>
         <div className="form-group">
             <input type="text"
                 className="form-control"
                 placeholder="Title"
                 value={this.state.title}
                 onChange={ this.handleTitleChange } />
         </div>
         <div className="form-group">
             <input type="text"
                 className="form-control"
                 placeholder="Artist"
                 value={this.state.artist}
                 onChange={ this.handleArtistChange } />
         </div>
         <div className="form-group">
             <input type="text"
             className="form-control"
             placeholder="Link"
             value={this.state.link}
             onChange={ this.handleLinkChange } />
         </div>
         <button type="submit" className="btn btn-primary"
                onClick={this.handleSubmit}>Add</button>
     </form>
     </body>
     );
 }
}

